# Pole Erection & Material Management (Android starter project)

An offline-first Android Studio project for LT, HT 11KV, RDSS and other distribution pole work.

## Included
- Project name, work type and feeder/area
- Pole number, type, height, status and landmark
- GPS capture (requires location permission)
- Open saved pole coordinates in a maps app
- Pole-wise standard/custom material rows and quantities
- Project-wise material totals
- Site photo attachment
- CSV export for Excel using Android's Save dialog
- JSON backup and restore
- Local browser storage inside the app; no account or cloud sync

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle to sync (internet is needed for the Android Gradle Plugin).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/`.

## Important limitations / next production steps
- This is a functional starter/MVP, not a field-validated production release.
- Data is stored locally in the app WebView. Export JSON backups regularly; uninstalling/clearing app data can erase records.
- GPS requires Android location permission and device location enabled.
- The app opens the device's map app for a coordinate; it does not embed an offline map.
- Photo storage is local and may increase app storage usage.
- PDF export, user login, cloud sync/multi-user access, map-based pole plotting, and configurable material templates are not included yet.
- Material names/quantities are records only; engineering quantities and safety specifications must be checked against the approved project drawings/BOM.
