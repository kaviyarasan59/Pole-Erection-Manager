package com.rdss.polemapping

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.views.overlay.MapEventsOverlay
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Pole(val id: String, var number: String, var type: String, var lat: Double, var lon: Double, var materials: MutableList<MaterialItem> = mutableListOf())
data class MaterialItem(var name: String, var quantity: Double, var unit: String)

class MainActivity : Activity(), LocationListener {
    private lateinit var map: MapView
    private lateinit var status: TextView
    private lateinit var locationManager: LocationManager
    private val poles = mutableListOf<Pole>()
    private var pendingPoint: GeoPoint? = null
    private val poleTypes = arrayOf("9M 300kg", "9M 400kg", "9M Square pole", "11M RSJ", "8M LT")
    private val prefs by lazy { getSharedPreferences("rdss_data", MODE_PRIVATE) }
    private val requestLocation = 100
    private val importCsv = 200
    private val importKml = 201
    private val exportCsv = 300
    private val exportKml = 301

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        loadPoles()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = TextView(this).apply {
            text = "RDSS POLE MAPPING  •  GPS / MATERIALS"
            textSize = 17f; setTextColor(0xffffffff.toInt()); setBackgroundColor(0xff12343b.toInt())
            setPadding(14, 16, 14, 16)
        }
        root.addView(header)
        status = TextView(this).apply { text = "Ready • ${poles.size} poles saved"; setPadding(12, 7, 12, 7); textSize = 13f }
        root.addView(status)
        map = MapView(this)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(15.0)
        map.controller.setCenter(GeoPoint(13.0827, 80.2707))
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addButton(row1, "My GPS") { locateMe() }
        addButton(row1, "Add pole") { addPoleDialog(pendingPoint ?: map.mapCenter as GeoPoint) }
        addButton(row1, "Pole list") { showPoleList() }
        root.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addButton(row2, "Materials") { choosePoleForMaterials() }
        addButton(row2, "Import CSV") { pickFile(importCsv, "text/*") }
        addButton(row2, "Import KML") { pickFile(importKml, "application/vnd.google-earth.kml+xml") }
        root.addView(row2)
        val row3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addButton(row3, "Export CSV") { createExport(exportCsv, "text/csv", "rdss_poles.csv") }
        addButton(row3, "Export KML") { createExport(exportKml, "application/vnd.google-earth.kml+xml", "rdss_poles.kml") }
        addButton(row3, "Offline map help") { offlineInfo() }
        root.addView(row3)
        setContentView(root)
        val receiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean { pendingPoint = p; status.text = "Selected map point: %.6f, %.6f".format(p.latitude, p.longitude); return true }
            override fun longPressHelper(p: GeoPoint): Boolean { pendingPoint = p; addPoleDialog(p); return true }
        }
        map.overlays.add(MapEventsOverlay(receiver))
        redrawMarkers()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestLocation)
        }
    }

    private fun addButton(row: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() } }
        row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
    }
    private fun locateMe() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestLocation); return
        }
        try {
            val last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (last != null) showLocation(last)
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1500L, 2f, this)
            status.text = if (last == null) "Waiting for GPS fix…" else "GPS: %.6f, %.6f".format(last.latitude, last.longitude)
        } catch (e: Exception) { status.text = "GPS unavailable: ${e.message}" }
    }
    override fun onLocationChanged(location: Location) { showLocation(location); try { locationManager.removeUpdates(this) } catch (_: Exception) {} }
    private fun showLocation(l: Location) {
        val p = GeoPoint(l.latitude, l.longitude); pendingPoint = p; map.controller.animateTo(p)
        status.text = "GPS: %.6f, %.6f".format(l.latitude, l.longitude)
    }
    @Deprecated("Deprecated in Android")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    private fun addPoleDialog(point: GeoPoint) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 8, 22, 0) }
        val number = EditText(this).apply { hint = "Pole number / ID" }
        val types = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, poleTypes) }
        box.addView(number); box.addView(types)
        AlertDialog.Builder(this).setTitle("Add pole at %.6f, %.6f".format(point.latitude, point.longitude))
            .setView(box).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val num = number.text.toString().trim().ifBlank { "P-${System.currentTimeMillis() % 100000}" }
                poles.add(Pole(System.currentTimeMillis().toString(), num, types.selectedItem.toString(), point.latitude, point.longitude))
                savePoles(); redrawMarkers(); status.text = "Saved $num • ${poles.size} poles"
            }.show()
    }
    private fun showPoleList() {
        if (poles.isEmpty()) { AlertDialog.Builder(this).setMessage("No poles yet. Tap the map to select a point, then Add pole. Long-press the map to add directly.").setPositiveButton("OK", null).show(); return }
        val labels = poles.map { "${it.number} • ${it.type} • %.5f, %.5f".format(it.lat, it.lon) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pole list (${poles.size})").setItems(labels) { _, which ->
            val p = poles[which]; map.controller.animateTo(GeoPoint(p.lat, p.lon))
            AlertDialog.Builder(this).setTitle("${p.number} • ${p.type}")
                .setItems(arrayOf("View materials", "Add material", "Delete pole")) { _, action ->
                    when (action) { 0 -> showMaterials(p); 1 -> addMaterialDialog(p); 2 -> AlertDialog.Builder(this).setMessage("Delete ${p.number}?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> poles.remove(p); savePoles(); redrawMarkers() }.show() }
                }.show()
        }.setPositiveButton("Close", null).show()
    }
    private fun choosePoleForMaterials() {
        if (poles.isEmpty()) { toast("Add a pole first"); return }
        AlertDialog.Builder(this).setTitle("Choose pole").setItems(poles.map { "${it.number} • ${it.type}" }.toTypedArray()) { _, i -> showMaterials(poles[i]) }.show()
    }
    private fun showMaterials(p: Pole) {
        val summary = if (p.materials.isEmpty()) "No materials added." else p.materials.joinToString("\n") { "${it.name}: ${it.quantity} ${it.unit}" }
        AlertDialog.Builder(this).setTitle("${p.number} materials").setMessage(summary)
            .setNeutralButton("Add material") { _, _ -> addMaterialDialog(p) }.setPositiveButton("Done", null).show()
    }
    private fun addMaterialDialog(p: Pole) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 8, 22, 0) }
        val name = EditText(this).apply { hint = "Material name (e.g. insulator)" }
        val qty = EditText(this).apply { hint = "Quantity"; inputType = 8194 }
        val unit = EditText(this).apply { hint = "Unit (Nos, m, kg)" }
        box.addView(name); box.addView(qty); box.addView(unit)
        AlertDialog.Builder(this).setTitle("Add material to ${p.number}").setView(box).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim(); val q = qty.text.toString().toDoubleOrNull()
                if (n.isBlank() || q == null || q < 0) { toast("Enter a material name and valid quantity"); return@setPositiveButton }
                p.materials.add(MaterialItem(n, q, unit.text.toString().trim().ifBlank { "Nos" })); savePoles(); toast("Material saved")
            }.show()
    }

    private fun redrawMarkers() {
        map.overlays.removeAll { it is Marker }
        poles.forEach { p ->
            val m = Marker(map).apply {
                position = GeoPoint(p.lat, p.lon); title = "${p.number} • ${p.type}"
                snippet = if (p.materials.isEmpty()) "No materials" else p.materials.joinToString(", ") { "${it.name} ${it.quantity}${it.unit}" }
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                setOnMarkerClickListener { marker, _ ->
                    AlertDialog.Builder(this@MainActivity).setTitle(marker.title).setMessage(marker.snippet ?: "")
                        .setPositiveButton("Materials") { _, _ -> showMaterials(p) }
                        .setNeutralButton("Add material") { _, _ -> addMaterialDialog(p) }
                        .setNegativeButton("Close", null).show(); true
                }
            }; map.overlays.add(m)
        }
        map.invalidate()
    }
    private fun savePoles() {
        val arr = JSONArray()
        poles.forEach { p ->
            val mats = JSONArray(); p.materials.forEach { mats.put(JSONObject().put("name", it.name).put("quantity", it.quantity).put("unit", it.unit)) }
            arr.put(JSONObject().put("id", p.id).put("number", p.number).put("type", p.type).put("lat", p.lat).put("lon", p.lon).put("materials", mats))
        }
        prefs.edit().putString("poles", arr.toString()).apply()
    }
    private fun loadPoles() {
        try {
            val arr = JSONArray(prefs.getString("poles", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val mats = mutableListOf<MaterialItem>(); val ma = o.optJSONArray("materials") ?: JSONArray()
                for (j in 0 until ma.length()) { val m = ma.getJSONObject(j); mats.add(MaterialItem(m.optString("name"), m.optDouble("quantity"), m.optString("unit", "Nos"))) }
                poles.add(Pole(o.optString("id"), o.optString("number"), o.optString("type"), o.optDouble("lat"), o.optDouble("lon"), mats))
            }
        } catch (_: Exception) {}
    }

    private fun pickFile(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(i, code)
    }
    private fun createExport(code: Int, mime: String, name: String) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, name) }
        startActivityForResult(i, code)
    }
    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            when (requestCode) {
                exportCsv -> contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { w ->
                    w.write("pole_number,pole_type,latitude,longitude,material_name,quantity,unit\n")
                    poles.forEach { p ->
                        if (p.materials.isEmpty()) w.write("${csv(p.number)},${csv(p.type)},${p.lat},${p.lon},,,\n")
                        else p.materials.forEach { m -> w.write("${csv(p.number)},${csv(p.type)},${p.lat},${p.lon},${csv(m.name)},${m.quantity},${csv(m.unit)}\n") }
                    }
                }
                exportKml -> contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { w ->
                    w.write("""<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>RDSS Poles</name>""")
                    poles.forEach { p ->
                        val desc = p.materials.joinToString("; ") { "${it.name}: ${it.quantity} ${it.unit}" }
                        w.write("<Placemark><name>${xml(p.number)} - ${xml(p.type)}</name><description>${xml(desc)}</description><Point><coordinates>${p.lon},${p.lat},0</coordinates></Point></Placemark>")
                    }; w.write("</Document></kml>")
                }
                importCsv -> {
                    val lines = contentResolver.openInputStream(uri)!!.bufferedReader().readLines()
                    var added = 0
                    lines.drop(1).forEach { line ->
                        val c = parseCsvLine(line)
                        if (c.size >= 4) {
                            val lat = c[2].toDoubleOrNull(); val lon = c[3].toDoubleOrNull()
                            if (lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0) {
                                val pole = poles.find { it.number == c[0] && it.lat == lat && it.lon == lon }
                                    ?: Pole(System.currentTimeMillis().toString() + added, c[0], c[1].ifBlank { poleTypes[0] }, lat, lon).also { poles.add(it) }
                                if (c.size >= 7 && c[4].isNotBlank()) pole.materials.add(MaterialItem(c[4], c[5].toDoubleOrNull() ?: 0.0, c[6].ifBlank { "Nos" }))
                                added++
                            }
                        }
                    }
                    savePoles(); redrawMarkers(); toast("Imported $added CSV rows")
                }
                importKml -> {
                    val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    val placemarks = Regex("<Placemark>(.*?)</Placemark>", RegexOption.DOT_MATCHES_ALL).findAll(text)
                    var added = 0
                    placemarks.forEach { match ->
                        val body = match.groupValues[1]
                        fun tag(t: String) = Regex("<$t[^>]*>(.*?)</$t>", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1)?.trim()?.let { android.text.Html.fromHtml(it, 0).toString() } ?: ""
                        val title = tag("name"); val coords = tag("coordinates").split(",")
                        if (coords.size >= 2) {
                            val lon = coords[0].trim().toDoubleOrNull(); val lat = coords[1].trim().toDoubleOrNull()
                            if (lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0) {
                                poles.add(Pole(System.currentTimeMillis().toString() + added, title.ifBlank { "Imported-${added+1}" }, poleTypes[0], lat, lon)); added++
                            }
                        }
                    }
                    savePoles(); redrawMarkers(); toast("Imported $added KML placemarks")
                }
            }
            status.text = "Done • ${poles.size} poles saved"
        } catch (e: Exception) { toast("File operation failed: ${e.message}") }
    }
    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun parseCsvLine(s: String): List<String> {
        val out = mutableListOf<String>(); val b = StringBuilder(); var quoted = false; var i = 0
        while (i < s.length) { val ch = s[i]
            if (ch == '"') { if (quoted && i+1 < s.length && s[i+1] == '"') { b.append('"'); i++ } else quoted = !quoted }
            else if (ch == ',' && !quoted) { out.add(b.toString()); b.setLength(0) } else b.append(ch)
            i++
        }; out.add(b.toString()); return out
    }
    private fun offlineInfo() {
        AlertDialog.Builder(this).setTitle("Offline map").setMessage("This app caches map tiles as you view them online. For field use without internet, open and zoom the required survey area while online first. Only cached areas will display offline. For larger offline areas, use a legally obtained offline tile package; do not bulk-download tiles against the map provider's terms.")
            .setPositiveButton("OK", null).show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onResume() { super.onResume(); if (::map.isInitialized) map.onResume() }
    override fun onPause() { super.onPause(); if (::map.isInitialized) map.onPause(); try { locationManager.removeUpdates(this) } catch (_: Exception) {} }
}
